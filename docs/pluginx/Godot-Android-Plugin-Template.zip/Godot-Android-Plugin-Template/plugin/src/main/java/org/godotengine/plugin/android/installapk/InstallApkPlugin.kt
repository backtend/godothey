package org.godotengine.plugin.android.installapk

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot
import java.io.File

/**
 * 对应 GDScript 里的:
 *   Engine.get_singleton("InstallApk").install(real_apk_path)
 *
 * 插件名必须和 getPluginName() 返回值一致，Godot 才能用
 * Engine.has_singleton("InstallApk") 找到它。
 */
class InstallApkPlugin(godot: Godot) : GodotPlugin(godot) {

    override fun getPluginName(): String = "InstallApk"

    override fun getPluginSignals(): MutableSet<SignalInfo> {
        return mutableSetOf(
            // Android 8.0+ 未授权"安装未知应用"权限时触发
            SignalInfo("install_permission_denied"),
            // 拉起系统安装器失败(比如文件不存在/URI异常)时触发, 参数是错误信息
            SignalInfo("install_launch_failed", String::class.java)
        )
    }

    /**
     * Android 8.0 (API 26) 起, 每个来源 App 需要用户手动授权
     * "允许安装未知应用" 才能触发安装意图, 建议 install() 前先查一下。
     */
    @UsedByGodot
    fun canInstall(): Boolean {
        val activity = activity ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            activity.packageManager.canRequestPackageInstalls()
        } else {
            true
        }
    }

    /**
     * 跳转系统设置页, 让用户手动打开"允许来自此来源的应用安装"开关。
     * 用户设置完之后一般会回到你的App, 你可以在 _on_confirm 之类的地方
     * 再次调用 install() 重试。
     */
    @UsedByGodot
    fun requestInstallPermission() {
        val activity = activity ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                data = Uri.parse("package:${activity.packageName}")
            }
            activity.startActivity(intent)
        }
    }

    /**
     * 拉起系统安装器。
     *
     * @param apkPath 必须是"真实的文件系统绝对路径"，不能是 Godot 的
     *                user:// 虚拟路径！在 GDScript 侧调用前先用
     *                ProjectSettings.globalize_path(path) 转换一次。
     */
    @UsedByGodot
    fun install(apkPath: String) {
        val activity = activity ?: return
        val apkFile = File(apkPath)

        if (!apkFile.exists()) {
            emitSignal("install_launch_failed", "文件不存在: $apkPath")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !canInstall()) {
            emitSignal("install_permission_denied")
            return
        }

        try {
            // authority 要和 AndroidManifest.xml 里 <provider android:authorities="..."/> 完全一致
            val authority = "${activity.packageName}.installapk.fileprovider"
            val apkUri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                // Android 7.0+ 禁止直接暴露 file:// Uri, 必须走 FileProvider
                FileProvider.getUriForFile(activity, authority, apkFile)
            } else {
                Uri.fromFile(apkFile)
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            activity.startActivity(intent)
        } catch (e: Exception) {
            emitSignal("install_launch_failed", e.message ?: "未知错误")
        }
    }
}