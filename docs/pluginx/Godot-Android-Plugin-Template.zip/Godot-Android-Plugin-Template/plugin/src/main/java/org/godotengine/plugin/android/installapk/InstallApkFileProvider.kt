package org.godotengine.plugin.android.installapk

import androidx.core.content.FileProvider

/**
 * 单纯继承一下 androidx 的 FileProvider，不加任何逻辑。
 *
 * 目的只有一个：让 AndroidManifest 里 <provider android:name="..."/>
 * 用一个跟 Godot 引擎自带 FileProvider 不同的类名，
 * 这样 Android Gradle Plugin 的 Manifest Merger 就不会把两者当成
 * "同一个组件的两份不同声明"从而报冲突。
 *
 * FileProvider.getUriForFile() 是静态方法，调用时只看 authority，
 * 跟这里具体是哪个子类无关，所以插件代码不需要改动。
 */
class InstallApkFileProvider : FileProvider()